/**
 * 
 */

function f1(){
	alert("Hello from f1 of test.js file!")
}