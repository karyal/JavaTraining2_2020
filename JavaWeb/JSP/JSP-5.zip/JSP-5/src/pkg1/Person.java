package pkg1;

public class Person {
	private String fullName, contactAddress, emailAddress;


	public Person() {	
		this.fullName = "";
		this.contactAddress = "";
		this.emailAddress = "";
	}
	
	public Person(String fullName, String contactAddress, String emailAddress) {
		super();
		this.fullName = fullName;
		this.contactAddress = contactAddress;
		this.emailAddress = emailAddress;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getContactAddress() {
		return contactAddress;
	}

	public void setContactAddress(String contactAddress) {
		this.contactAddress = contactAddress;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	@Override
	public String toString() {
		return "Person [fullName=" + fullName + ", contactAddress=" + contactAddress + ", emailAddress=" + emailAddress
				+ "]";
	}	
}