package pkg1;

import java.io.Serializable;

public class Contact implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private int id;
	private String fullName;
	
	public Contact() {
		this.id = 0;
		this.fullName = "";
	}
	
	public Contact(int id, String fullName) {
		super();
		this.id = id;
		this.fullName = fullName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	@Override
	public String toString() {
		return "Contact [id=" + id + ", fullName=" + fullName + "]";
	}		
}