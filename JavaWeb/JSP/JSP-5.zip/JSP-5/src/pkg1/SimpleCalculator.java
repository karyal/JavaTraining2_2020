package pkg1;

public class SimpleCalculator {
	private int n1;
	private int n2;
	private int n3;
	
	public SimpleCalculator() {
		this.n1 = 0;
		this.n2 = 0;
		this.n3 = 0;
	}
	
	public SimpleCalculator(int n1, int n2) {
		this.n1 = n1;
		this.n2 = n2;
		this.n3 = 0;
	}

	public int getN1() {
		return n1;
	}

	public void setN1(int n1) {
		this.n1 = n1;
	}

	public int getN2() {
		return n2;
	}

	public void setN2(int n2) {
		this.n2 = n2;
	}

	public int getN3() {
		return n3;
	}

	public void setN3(int n3) {
		this.n3 = n3;
	}

	@Override
	public String toString() {
		return "SimpleCalculator [n1=" + n1 + ", n2=" + n2 + ", n3=" + n3 + "]";
	}	
	
	public void calc_sum() {
		this.n3=this.n1+this.n1;
	}
	public void calc_dif() {
		this.n3=this.n1-this.n1;
	}
	public void calc_prd() {
		this.n3=this.n1*this.n1;
	}
	public void calc_div() {
		this.n3=this.n1/this.n1;
	}
}