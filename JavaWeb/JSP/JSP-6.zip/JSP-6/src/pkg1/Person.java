package pkg1;

public class Person {

}
