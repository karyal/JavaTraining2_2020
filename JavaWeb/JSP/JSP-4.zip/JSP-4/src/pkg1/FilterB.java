package pkg1;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

@WebFilter("/FilterB")
public class FilterB implements Filter {
    
    public FilterB() {
    	System.out.println("FilterB() ... of FilterB");
    }
    
    @Override
	public void destroy() {
		System.out.println("destroy() ... of FilterB");
	}
	
    @Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		System.out.println("FilterB ... before execution ");
		chain.doFilter(request, response);
		System.out.println("FilterB ... after execution ");
	}
	
	@Override
	public void init(FilterConfig fConfig) throws ServletException {
		System.out.println("init() ... of FilterB");
	}
}