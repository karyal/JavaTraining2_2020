package pkg1;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

@WebFilter("/FilterA")
public class FilterA implements Filter {
    
    public FilterA() {
    	System.out.println("FilterA() ... of FilterA");
    }
    
    @Override
	public void destroy() {
		System.out.println("destroy() ... of FilterA");
	}
	
    @Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		System.out.println("FilterA ... before execution ");
		chain.doFilter(request, response);
		System.out.println("FilterA ... after execution ");
	}
	
	@Override
	public void init(FilterConfig fConfig) throws ServletException {
		System.out.println("init() ... of FilterA");
	}
}