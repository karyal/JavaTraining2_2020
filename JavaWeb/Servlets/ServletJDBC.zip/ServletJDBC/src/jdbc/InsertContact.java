package jdbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import libs.Contact;
import libs.MyDatabase;


public class InsertContact extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		service(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		service(request, response);
	}
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");

		//Receive values from Web Form-3
		String name = request.getParameter("txt_name");
		String address = request.getParameter("txt_address");
		String email = request.getParameter("txt_email"); 
		String phone = request.getParameter("txt_phone");

		Contact contact = new Contact(0, name, address, email, phone);
		MyDatabase mdb = new MyDatabase();
		boolean result = mdb.insert(contact);
		if (result==true) {
			//System.out.println("Insert Record Successfully");
			out.println("Insert Record Successfully");
		}
		else {
			//System.out.println("Error to insert record");
			out.println("Error to insert record");
		}
		out.println("<br/><br/><br/><br/><br/>");
		out.println("<a href='displayall'>Index</a>");
	}
}