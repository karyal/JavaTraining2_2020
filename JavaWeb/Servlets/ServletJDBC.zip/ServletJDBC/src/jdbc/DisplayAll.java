package jdbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import libs.Contact;
import libs.MyDatabase;


public class DisplayAll extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		service(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		service(request, response);
	}
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		MyDatabase mdb = new MyDatabase();
		List contacts = mdb.get_all();
		
		out.println("<a href='NewContact.jsp'>ADD NEW</a>");				
		out.println("<table border=1>");
		out.println("<tr><td>SN</td><td>NAME</td><td>ADDRESS</td><td>EMAIL</td><td>PHONE</td><td>CONTROL</td></tr>");		
		
		for(int i =0; i<contacts.size(); i++) {
			Contact tmp_contact = (Contact) contacts.get(i); 
			out.println("<tr><td>"+ tmp_contact.getSn() +"</td><td>"+ tmp_contact.getName() +"</td><td>"+ tmp_contact.getAddress() +"</td><td>"+ tmp_contact.getEmail() +"</td><td>"+ tmp_contact.getPhone() +"</td><td><a href='seven?id="+ tmp_contact.getSn() +"'>EDIT</a> | <a href='nine?id="+ tmp_contact.getSn() +"'>DELETE</a> </td></tr>");
		}		
		out.println("</table");
	}		
}