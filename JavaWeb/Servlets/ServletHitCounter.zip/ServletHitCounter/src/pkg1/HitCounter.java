package pkg1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HitCounter extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private int count;
	
	public void init() {
		count=0;//Read from file or database
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		service(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		service(request, response);
	}
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		count++;
		out.println("Visitors : "+count);
		out.close();		
	}
	
	public void destroy() {
		count = 0;//Update on file or database
	}
}