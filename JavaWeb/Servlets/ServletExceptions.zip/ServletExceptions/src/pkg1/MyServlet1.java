package pkg1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MyServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		service(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		service(request, response);
	}
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		// Analyze the Servlet exception       
		Throwable throwable = (Throwable) request.getAttribute("javax.servlet.error.exception");
		Integer status_code = (Integer) request.getAttribute("javax.servlet.error.status_code");
	    String servlet_name = (String) request.getAttribute("javax.servlet.error.servlet_name");
	    String request_uri = (String) request.getAttribute("javax.servlet.error.request_uri");
	    
	    if (servlet_name == null) {
	    	servlet_name ="Unknown";
	    }
	    if (request_uri == null) {
	    	request_uri ="Unknown";
	    }
	    
	    out.println("<html><head><title>Error/Exception Information</title></head><body>");
	    
	    if(throwable == null && status_code == null) {
	    	//No Exceptions
	    	//Processing from user
	    	try {
	    		out.println("<p>No Error Infos Exist!</p>");
	    		//out.println("<a href='../'>Index</a>");
	    	}
	    	catch(Exception ex){
	    		out.println("<p>Error : "+ex.getMessage()+"</p>");
	    	}
	    }
	    else if(status_code !=null) {
	    	out.println("Status Code : "+status_code);
	    }
	    else {
	    	out.println("<p>Error Information</p>");
	    	out.println("<p>Servlet Name : "+ servlet_name +"</p>");
	    	out.println("<p>Error Type : "+ throwable.getClass().getName() +"</p>");
	    	out.println("<p>Request URI: " + request_uri + "</p>");
	    	out.println("<p>Message : " + throwable.getMessage() + "</p>");
	    }
	    out.println("</body></html>");	    	    
		out.close();
	}	
}