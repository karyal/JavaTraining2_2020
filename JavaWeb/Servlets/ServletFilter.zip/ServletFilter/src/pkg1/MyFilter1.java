package pkg1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class MyFilter1 implements Filter {

	public void destroy() {	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		out.println("<p>Before Filter1 Invoke ....</p>");		
		chain.doFilter(request, response);
		out.println("<p>After Filter Invoke ....</p>");
		out.close();
	}
	
	public void init(FilterConfig fConfig) throws ServletException { }
}