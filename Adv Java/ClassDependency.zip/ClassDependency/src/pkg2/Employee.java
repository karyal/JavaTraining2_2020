package pkg2;

public class Employee implements Person{

	@Override
	public String get_info() {		
		return "Hello from Employee Class";
	}
	
}
