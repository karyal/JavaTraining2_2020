package pkg2;

public interface Person {
	public String get_info();
}
