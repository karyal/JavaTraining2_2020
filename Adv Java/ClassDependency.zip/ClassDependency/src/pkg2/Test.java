package pkg2;

public class Test {
	public static void main(String[] args) {
		
		Person p;
		
		p = new Employee();
		System.out.println(p.get_info());
		
		p = new Teacher();
		System.out.println(p.get_info());
	} 
}