package pkg2;

public class Teacher implements Person{
	
	@Override
	public String get_info() {		
		return "Hello from Teacher Class";
	}
	
}