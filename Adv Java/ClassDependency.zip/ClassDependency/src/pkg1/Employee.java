package pkg1;

public class Employee {
	private Person person;
	private String department;
	
	public Employee() {
		person = new Person();
		department = "NA";
	}

	public Employee(Person person, String department) {
		this.person = person;
		this.department = department;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	@Override
	public String toString() {
		return "Employee [person=" + person + ", department=" + department + "]";
	}
}
