package pkg1;

public class Test {
	public static void main(String[] args) {
		Employee emp1 = new Employee();
		System.out.println(emp1);
		
		//Cohesion and Coupling in Java?
		
	}
}