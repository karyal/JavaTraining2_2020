package pkg1;

//Plain Old Java Object (POJO) -> Represents Database Table (Carrier, Program to DB, DB to Program)

public class Person {
	//Instance variables (private)
	//Constructors (public)
	//Setters //(public)
	//Getters //(public)
	//toString //(public)
	
	private int pid;
	private String name;
	private double salary;
	
	public Person() {
		this.pid = 0;
		this.name = "";
		this.salary=0.0;
	}
	
	public Person(int pid, String name, double salary) {
		this.pid = pid;
		this.name = name;
		this.salary=salary;
	}
		
	public int getPid() {
		return pid;
	}
	
	public void setPid(int pid) {
		this.pid = pid;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Person [pid=" + pid + ", name=" + name + ", salary=" + salary + "]";
	}	
}