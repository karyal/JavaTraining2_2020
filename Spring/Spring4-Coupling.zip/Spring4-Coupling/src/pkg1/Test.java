package pkg1;

public class Test {
	
	public static void main(String[] args) {		
		
		PrimaryStudent ps =  new PrimaryStudent();
		
		SecondaryStudent ss1 =  new SecondaryStudent(new Person());
		SecondaryStudent ss2 =  new SecondaryStudent(new Person(2,"NAME2"));
		
		System.out.println(ps.get_message());
		System.out.println(ss1.get_message());
		System.out.println(ss2.get_message());
	}
}