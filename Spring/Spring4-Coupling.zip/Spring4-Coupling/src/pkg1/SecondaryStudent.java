package pkg1;

public class SecondaryStudent implements Student{
	//Instance variable
	private Person person;
	
	public SecondaryStudent(Person person) {
		//this.person = new Person();//Tight Coupling - Static/Fixed
		this.person = person;//Loose Coupling - Dynamic/Flexible
	}
	
	@Override
	public String get_message() {		
		return "Hi from Secondary Student!";
	}
}