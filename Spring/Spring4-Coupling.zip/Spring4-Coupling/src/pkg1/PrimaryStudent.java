package pkg1;

public class PrimaryStudent implements Student{
	//Instance variable
	//Relationship between two classes.
	Person person; //Class Type
	
	public PrimaryStudent() {
		//Initialize an object by default Constructor - Static Relationship
		this.person = new Person(); 
	}
	
	@Override
	public String get_message() {		
		return "Hi from primary student!";
	}
}
