package pkg1;

public interface Student {
	public String get_message();
}